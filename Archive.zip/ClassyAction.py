import random #simulation runs on possibilty of a situation happening
import file

from BusClass import Bus
from PersonClass import Person
from TownClass import Town


townNames = ["OceanCity", "DownTown", "Princeton", "Boston", "NYC", "ChinaTown", "Chicago", "Greenwich", "ColorVille", "WaterVille", "Mercer", "LastTown"]
for index in range(len(townNames)): #creates 12 town objects
    newTown = Town(townNames[index])
    Town.county.append(newTown) #adds them to county

#creates all the bus objects and their routes
def createBuses():
    bus1 = Bus(1, 20)         #be able to move forward and backwards
    bus1ListRoute = [Town.county[0], Town.county[2], Town.county[4], Town.county[10], Town.county[11]] #stops at these towns
    bus1.setBusRoute(bus1ListRoute)
    bus1.setStartLocation(bus1ListRoute[0]) #gives the bus a starting town(first town in its route)

    bus2 = Bus(2, 25)
    bus2ListRoute = [Town.county[11], Town.county[3], Town.county[5], Town.county[7], Town.county[8]]
    bus2.setBusRoute(bus2ListRoute)
    bus2.setStartLocation(bus2ListRoute[0])

    bus3 = Bus(3, 15)
    bus3ListRoute = [Town.county[4], Town.county[6], Town.county[8], Town.county[1], Town.county[5]]
    bus3.setBusRoute(bus3ListRoute)
    bus3.setStartLocation(bus3ListRoute[0])

    bus4 = Bus(4, 20)
    bus4ListRoute = [Town.county[1], Town.county[2], Town.county[6], Town.county[9], Town.county[7]]
    bus4.setBusRoute(bus4ListRoute)
    bus4.setStartLocation(bus4ListRoute[0])

    bus5 = Bus(5, 30)
    bus5ListRoute = [Town.county[3], Town.county[0], Town.county[11], Town.county[4], Town.county[10]]
    bus5.setBusRoute(bus5ListRoute)
    bus5.setStartLocation(bus5ListRoute[0])
        #Creates 5 bus objects, and gives each bus a certain route(the name(str) of the town is added to busroute)

    bus1.setDestinationLocation()   #second element is the starting destination, automatically updates after these is called
    bus2.setDestinationLocation()
    bus3.setDestinationLocation()
    bus4.setDestinationLocation()
    bus5.setDestinationLocation()

def showProgress():
    print("\n At this moment, the simulation looks like this: \n")
    for town in Town.county:
        print(str(town.getName()))
        print("\tPopulation: " + str(len(town.getPeopleWithinTown())))
        print("\tBuses: " + str(len(town.getBusesWithinTown())))

def allBusesMove():
    for bus in range(5): #all 5 buses move to the next town
        Bus.busList[bus].busToNextTown()

def runSimulation():
    for bus in Bus.busList:  #goes thru each bus
        busLocation = bus.getLocation()  #town object
        humansWithinTown = busLocation.getPeopleWithinTown() #a list of people objects in the town
        peopleInBus = bus.getPassengersInside() #a list of people objects on the bus

        if peopleInBus != []: #if the bus has at least one person
            getOff = random.randint(0, len(peopleInBus))  #random amount of people
            for i in range(getOff):
                numbOfPerson = random.randint(0, len(peopleInBus) - 1) #random people are chosen from the bus
                personPicked = peopleInBus[numbOfPerson]
                bus.exitBus(personPicked) #person object gets off bus

        if len(humansWithinTown) != 0: #if the town is not empty
            num = random.randint(0,len(humansWithinTown)) #random number of people in the town are chosen
            for i in range(num):
                numOfPerson = random.randint(0, len(humansWithinTown) - 1)   #randomly choses amount of people from the town                        #what if the same person is chosen twice?
                personChosen = humansWithinTown[numOfPerson]
                bus.enterBus(personChosen)      #person object enters the bus
    allBusesMove()

def createFileBus(numb, seatCount, locationName):
    bus1ListRoute = [Town.county[0], Town.county[2], Town.county[4], Town.county[10], Town.county[11]]
    bus2ListRoute = [Town.county[11], Town.county[3], Town.county[5], Town.county[7], Town.county[8]]
    bus3ListRoute = [Town.county[4], Town.county[6], Town.county[8], Town.county[1], Town.county[5]]
    bus4ListRoute = [Town.county[1], Town.county[2], Town.county[6], Town.county[9], Town.county[7]]
    bus5ListRoute = [Town.county[3], Town.county[0], Town.county[11], Town.county[4], Town.county[10]]

    if numb == 1: #(bus1)
        bus1 = Bus(numb, seatCount)
        bus1.setBusRoute(bus1ListRoute)
        for bus in range(len(bus1ListRoute)):
            if bus1ListRoute[bus].getName() == locationName:        #if the town is the name
                bus1.setStartLocation(bus1ListRoute[bus])       #location of new start (town)
    if numb == 2: #bus #2
        bus2 = Bus(numb, seatCount)
        bus2.setBusRoute(bus2ListRoute)
        for bus in range(len(bus2ListRoute)):
            if bus2ListRoute[bus].getName() == locationName:  # if the town is the name
                bus2.setStartLocation(bus2ListRoute[bus])
    if numb == 3: #bus3
        bus3 = Bus(numb, seatCount)
        bus3.setBusRoute(bus3ListRoute)
        for bus in range(len(bus3ListRoute)):
            if bus3ListRoute[bus].getName() == locationName:  # if the town is the name
                bus3.setStartLocation(bus3ListRoute[bus])
    if numb == 4: #bus4
        bus4 = Bus(numb, seatCount)
        bus4.setBusRoute(bus4ListRoute)
        for bus in range(len(bus4ListRoute)):
            if bus4ListRoute[bus].getName() == locationName:  # if the town is the name
                bus4.setStartLocation(bus4ListRoute[bus])
    else: #bus5
        bus5 = Bus(numb, seatCount)
        bus5.setBusRoute(bus5ListRoute)
        for bus in range(len(bus5ListRoute)):
            if bus5ListRoute[bus].getName() == locationName:  # if the town is the name
                bus5.setStartLocation(bus5ListRoute[bus])

def createFilePerson(Loc):  #it goes in order of people, so they have the same name
    for p in range(360): #360 people objects
        newPerson = Person()
        if len(Loc) > 1: #it's not a single int(bus)
            for t in range(len(Town.county)): #checks to see if the location is a town
                if Town.county[t].getName() == Loc:
                    newPerson.setLocation(Town.county[t])
        else: #location is a bus
            numB = int(Loc)
            newPerson.setLocation(Bus.busList[numB])

def useFileInfo():
    with open("saveState.txt", "r") as myFile:  #opening the file
        for line in myFile:
            lineStr = line #gets each line as a string
            listStr = lineStr.split(" ") #creates a list of strings
            if listStr[0] == "Bus":     #it is a bus object
                #create the bus object
                subTown = listStr[3].split("\n")
                towny = subTown[0] #gotten rid of \n
                createFileBus(int(listStr[1]), int(listStr[2]), towny)
            elif listStr[0] == "Person":
                 subTown = listStr[2].split("\n")
                 towny = subTown[0]  # gotten rid of \n
                 createFilePerson(towny)

            else: #listStr[0] is a Town
                #don't need to do anything because towns are created at the start no matter what
                x=0


print("Welcome to Genevieve's Bus Company Simulation")
print("If you would like to start a fresh simulation(input 1). If you want to import a previous file(input 0)")
userInp = int(input())

if userInp == 1: #run a new simulation
    createBuses()

    #creates 30 new people object and places them in a town
    for town in Town.county:
        for index in range(30):
            newPerson = Person()
            newPerson.setLocation(town) #persons location is the town object

    showProgress()
    print(" \n")

    runSimulation()
    showProgress()

    for n in range(10): #runs the code 10 times
        runSimulation()
    showProgress()

    print("The simulation has stopped. All current information has been stored in a file")
    file.getObjectsInTown() #passes a list of town objects
else:   #import the file and use its info
    useFileInfo() #starts program with information from file

    #runSimulation()                causing errors
    showProgress()



