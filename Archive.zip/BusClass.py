class Bus:
    '''This class will allow me to create a bus, each with their own bus number, number of seats, a passenger list,
     and location(including where they are departing from and their destination)'''

    busList = [] #list of buses created

    def __init__(self, bus_number, number_seats):
        self.myBusNumber = bus_number
        self.numberSeats = number_seats

        self.busRoute = [] #each bus object has a set bus route
        self.passengersOnBus = [] #every time a person gets on the bus, person object is added

        self.location = None  #current location/departing from
        self.destinationLocation = None

        self.busList.append(self)  #adds the bus object to the class variable busList
        self.count = 1 #variable used in busToNextTown , increment operator for bus movement. updates after first call

    def setBusRoute(self, listofRoutes):
        self.busRoute = listofRoutes   #bus route is a list of towns that the bus goes to

    def getBusRoute(self):
        return self.busRoute

    def getPassengersInside(self):
        return self.passengersOnBus

    def getDestinationLocation(self):
        return self.destinationLocation

    def getLocation(self):
        return self.location

    def setStartLocation(self, startTown): #where the bus begins/departs from
        self.location = startTown

    def busToNextTown(self): #bus moves to the next town in its list (forwards or backwards)
        loc = self.busRoute.index(self.location)

        if self.count == 1: #bus moves forwards
            if loc == (len(self.busRoute)-1): #the bus is at its final stop
                self.count = -1 #begins to move backwards
                self.busMoveBackwards(loc)
                self.setDestinationLocation() # every time the bus moves, its new destination will also change
            else:
                self.busMoveForward(loc)
                self.setDestinationLocation()
        else: #if count = -1
            if loc == 0: #the first(0th) town
                self.count = 1 #will move forward
                self.busMoveForward(loc)
                self.setDestinationLocation()
            else:
                self.busMoveBackwards(loc)
                self.setDestinationLocation()

    def busMoveForward(self, x): #bus moves to the next town in its route
        self.location = self.busRoute[x+1] #its location changes to the next town

    def busMoveBackwards(self, x): #bus starts at last stop in route and goes to first town
        self.location = self.busRoute[x-1]

    def setDestinationLocation(self):
        currentLoc = (self.busRoute).index(self.location)  # grabs location(#) within the busRoute list
        if currentLoc == 0: #it will always be the second element
            self.destinationLocation = self.busRoute[1] #Should be adding the town at that location in the busRoute
        elif currentLoc == (len(self.busRoute) - 1): #if its at the end
            self.destinationLocation = self.busRoute[len(self.busRoute) - 2] #the element before it is the next destination
        else:
            if self.count == 1: #if the bus is moving forwards
                self.destinationLocation = self.busRoute[currentLoc + 1] #destination is the next town
            else: #bus is going backwards
                self.destinationLocation = self.busRoute[currentLoc - 1]

    def getBusNumb(self):
        return self.myBusNumber

    def getNumberOfSeats(self):
        return self.numberSeats

    def enterBus(self, passenger): #passenger is a person object.
        if len(self.passengersOnBus) == self.numberSeats: #the bus is full
            return "Sorry, bus #" + str(self.myBusNumber) + "is full."
        else:
            self.passengersOnBus.append(passenger) #adds passenger (person object) to passengers
            passenger.setLocation(self) #sets the passengers location to the bus object

    def exitBus(self, passenger): #passenger leaves bus
        if passenger in self.passengersOnBus: #if the person is on the bus
            self.passengersOnBus.remove(passenger) #removes the passenger object from the passengersOnBus list
            passenger.setLocation(self.getLocation()) #changes persons location to the town the bus was in
        else:
            return (str(passenger.getName()) + " is not on bus#" + str(self.myBusNumber))








