'''I started out by drawing a bunch of towns(dots) and connecting them to each other with roads(lines). I first wanted
to have a road class but discovered it was easier to have a set list of towns in a buses route. I first created a person
 class, a bus class and a Town class. My town objects have 2 lists: people within and buses within, so that I could
easily find the location of a person or bus. Person class has a name and a location, the location is constantly updating
to whatever town or bus they are in. The difficult class was the bus one because it had so many functions and attributes.
 I started simple, by adding a person to the bus or removing the person from the bus. Then I had to figure out how to move
 the bus to the next town. I figured out how to move forward in the list, but once it reached the last town I wanted it
 to reverse direction. The busToNextTown() was the most challenging. I fixed my problem by having a class variable that
  was either equal to 1 or -1 which indicated the direction of travel. I also had trouble with running the simulation,
  it was very open ended and I didn't know how the outputs should look or if the user should input anything. I decided to
  run the simulation on randomness and probability, because real life is full of random choices. That is why I imported
   random, so people objects could have a chance to get on or off a bus. Finally, I struggled a lot with saving
   information on a file. I wish I had found a more efficient way to take info from my file and set it as the initial
   data for resuming a simulation. I had an issue where all my strings had \n in them, even though I was trying to
   go to the next line, I found a way around this, but If I had more time I would've liked to fix this. Finally, I had
   a problem with my population after using the file (when you input 0). I couldn't figure this out, but I would like
   to continue working on it so I can solve my last problem.


   While writing this code, I constantly encountered issues with objects and their attributes, I would save the name of
   a bus and later realize I need the bus object so I could access its attributes. I would have to go back and fix all
   my code. When working with objects, I am now always aware of holding the object instead of an attribute so I can
    get more information later, if needed.'''