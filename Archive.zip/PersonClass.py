
class Person:
    '''this class allows me to create a person with a name and a current location'''

    peopleCreated = [] #class variable that holds all person objects

    peopleCount = 0 #the number of people objects created

    def __init__(self, personName = "person"):
        self.myName = personName + str(self.peopleCount)
        Person.peopleCount = Person.peopleCount + 1 #adds 1 each time a person object is created
        self.location = None #setLocation() will manually set it
        self.peopleCreated.append(self) #current person object is added to peopleCreated

    def getName(self):
        return self.myName

    def setLocation(self, loc): #location is either a bus or town object
        self.location = loc






    def getLocation(self):
        return self.location





