from PersonClass import Person
from BusClass import Bus

class Town:
    '''This class allows me to create towns that each have a name, a bus and person population'''

    county = [] #list of 12 towns in simulation

    def __init__(self, name):
        self.townName = name
        self.peopleWithinTown = []
        self.busesWithinTown = []

    def getName(self):
        return self.townName

    def setBusesWithinTown(self):
        '''finds the buses within the current town and adds it to busesWithinTown'''
        self.busesWithinTown = [] #empties the list so that previous buses are erased
        for i in range(5):  #there are 5 buses in this simulation
            if (Bus.busList[i].getLocation()) == self: #if the current location of the bus is self
                self.busesWithinTown.append(Bus.busList[i])#adds the bus to buses busesWithinTown

    def getBusesWithinTown(self):
        self.setBusesWithinTown() #calls the function that fills the list with buses
        return self.busesWithinTown

    def setPeopleWithinTown(self):
        '''finds all people within the town and adds them to peopleWithinTown'''
        self.peopleWithinTown = []  #clears previous people, rechecks population each time
        for i in range(Person.peopleCount):  #number of people objects
            if Person.peopleCreated[i].getLocation() == self:
                self.peopleWithinTown.append(Person.peopleCreated[i])
        return self.peopleWithinTown

    def getPeopleWithinTown(self):
        self.setPeopleWithinTown()
        return self.peopleWithinTown












