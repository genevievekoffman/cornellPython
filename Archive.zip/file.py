'''saves information/current state of simulation in file'''
from BusClass import Bus
from PersonClass import Person
from TownClass import Town

def getObjectsInTown():

    with open("saveState.txt", "w") as myFile:  #write file
        for town in range(len(Town.county)):
            townName = str(Town.county[town].getName())
            myFile.write("Town" + " " + townName + "\n")

        for bus in range(len(Bus.busList)):
            busNumb = str(Bus.busList[bus].getBusNumb())
            busNumbPassengers = str(Bus.busList[bus].getNumberOfSeats())
            savedStartLoc = str(Bus.busList[bus].getLocation().getName())
            myFile.write("Bus"+ " " +busNumb+ " " + busNumbPassengers+ " " +savedStartLoc +  "\n") #Bus indicates its object type

        for person in range(len(Person.peopleCreated)):
            personName = str(Person.peopleCreated[person].getName())
            personLoc = Person.peopleCreated[person].getLocation() #returns bus or town
            locF = 0 #set to a town or bus
            if personLoc in Bus.busList: #if location is a bus
                locF = str(personLoc.getBusNumb()) #locf is the bus #
            else: #location is a town
                locF = str(Person.peopleCreated[person].getLocation().getName())            #location can be a town or BUS
            myFile.write("Person" + " " + personName + " " + locF + "\n")




